import 'package:flutter/material.dart';
import 'package:pdfx/pdfx.dart';

void main() => runApp(const ZaynabApp());

const gold = Color(0xFFE5B95C);
const cream = Color(0xFFF7F0E2);
const green = Color(0xFF063A35);
const dark = Color(0xFF031F1D);

class ZaynabApp extends StatelessWidget {
  const ZaynabApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'زينب عليها السلام',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: green),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  final sections = const [
    ('مقدمة', Icons.menu_book_rounded),
    ('حياتها', Icons.auto_stories_rounded),
    ('ولادتها ونشأتها', Icons.family_restroom_rounded),
    ('واقعة الطف', Icons.flag_rounded),
    ('خطابها ومواقفها', Icons.record_voice_over_rounded),
    ('وفاتها', Icons.local_library_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: CustomScrollView(
          slivers: [
            SliverAppBar(
              expandedHeight: 310,
              pinned: true,
              backgroundColor: dark,
              elevation: 0,
              actions: [
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.search, color: gold),
                ),
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.bookmark_border, color: gold),
                ),
                const SizedBox(width: 6),
              ],
              flexibleSpace: FlexibleSpaceBar(
                background: Stack(
                  fit: StackFit.expand,
                  children: [
                    Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Color(0xFF0A403B), dark],
                        ),
                      ),
                    ),
                    Positioned.fill(
                      child: CustomPaint(painter: OrnamentPainter()),
                    ),
                    const Align(
                      alignment: Alignment.center,
                      child: Padding(
                        padding: EdgeInsets.only(top: 30),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.auto_awesome, color: gold, size: 38),
                            SizedBox(height: 12),
                            Text(
                              'زينب',
                              style: TextStyle(
                                color: gold,
                                fontSize: 48,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            Text(
                              'عليها السلام',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                              ),
                            ),
                            SizedBox(height: 10),
                            Text(
                              'سيرة عظيمة ومواقف خالدة',
                              style: TextStyle(
                                color: Color(0xFFE8D8B0),
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
                child: _ContinueCard(
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const ReaderPage()),
                  ),
                ),
              ),
            ),

            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 14, 18, 12),
                child: Row(
                  children: [
                    const Text(
                      'أقسام الكتاب',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        color: dark,
                      ),
                    ),
                    const Spacer(),
                    TextButton(
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const ReaderPage()),
                      ),
                      child: const Text('عرض الكل'),
                    ),
                  ],
                ),
              ),
            ),

            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (context, i) => _SectionCard(
                    title: sections[i].$1,
                    icon: sections[i].$2,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const ReaderPage()),
                    ),
                  ),
                  childCount: sections.length,
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 1.18,
                ),
              ),
            ),

            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Expanded(
                      child: _SmallCard(
                        icon: Icons.star_rounded,
                        title: 'المفضلة',
                        subtitle: 'النصوص المحفوظة',
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _SmallCard(
                        icon: Icons.history_rounded,
                        title: 'آخر ما قرأت',
                        subtitle: 'استمر من هنا',
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SliverToBoxAdapter(child: SizedBox(height: 90)),
          ],
        ),
        bottomNavigationBar: NavigationBar(
          backgroundColor: dark,
          indicatorColor: gold.withOpacity(.22),
          selectedIndex: 0,
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.home_outlined, color: Colors.white70),
              selectedIcon: Icon(Icons.home, color: gold),
              label: 'الرئيسية',
            ),
            NavigationDestination(
              icon: Icon(Icons.menu_book_outlined, color: Colors.white70),
              selectedIcon: Icon(Icons.menu_book, color: gold),
              label: 'الكتاب',
            ),
            NavigationDestination(
              icon: Icon(Icons.search, color: Colors.white70),
              selectedIcon: Icon(Icons.search, color: gold),
              label: 'البحث',
            ),
            NavigationDestination(
              icon: Icon(Icons.bookmark_border, color: Colors.white70),
              selectedIcon: Icon(Icons.bookmark, color: gold),
              label: 'المفضلة',
            ),
          ],
          labelTextStyle: WidgetStateProperty.all(
            const TextStyle(color: Colors.white70),
          ),
        ),
      ),
    );
  }
}

class _ContinueCard extends StatelessWidget {
  final VoidCallback onTap;
  const _ContinueCard({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [dark, Color(0xFF0A4A43)],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: gold, width: 1.2),
        boxShadow: [
          BoxShadow(
            blurRadius: 18,
            offset: const Offset(0, 8),
            color: dark.withOpacity(.22),
          ),
        ],
      ),
      padding: const EdgeInsets.all(18),
      child: Row(
        children: [
          Container(
            width: 72,
            height: 92,
            decoration: BoxDecoration(
              color: const Color(0xFF102F2B),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: gold),
            ),
            child: const Icon(Icons.menu_book_rounded, color: gold, size: 38),
          ),
          const SizedBox(width: 16),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('متابعة القراءة',
                    style: TextStyle(
                        color: gold, fontSize: 22, fontWeight: FontWeight.bold)),
                SizedBox(height: 7),
                Text('بحث عن زينب الكبرى عليها السلام',
                    style: TextStyle(color: Colors.white, fontSize: 15)),
                SizedBox(height: 12),
                Text('القراءة من الملف الأصلي المرفق',
                    style: TextStyle(color: Colors.white70, fontSize: 12)),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: onTap,
            style: ElevatedButton.styleFrom(
              backgroundColor: gold,
              foregroundColor: dark,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
              ),
            ),
            child: const Text('اقرأ الآن'),
          ),
        ],
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final VoidCallback onTap;
  const _SectionCard(
      {required this.title, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: gold.withOpacity(.55)),
        ),
        padding: const EdgeInsets.all(14),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 38, color: gold),
            const SizedBox(height: 10),
            Text(title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: dark, fontSize: 17, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Icon(Icons.chevron_left, color: dark),
          ],
        ),
      ),
    );
  }
}

class _SmallCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const _SmallCard(
      {required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: dark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: gold.withOpacity(.6)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: gold, size: 28),
          const SizedBox(height: 8),
          Text(title,
              style: const TextStyle(
                  color: gold, fontWeight: FontWeight.bold, fontSize: 17)),
          Text(subtitle,
              style: const TextStyle(color: Colors.white70, fontSize: 12)),
        ],
      ),
    );
  }
}

class ReaderPage extends StatefulWidget {
  const ReaderPage({super.key});

  @override
  State<ReaderPage> createState() => _ReaderPageState();
}

class _ReaderPageState extends State<ReaderPage> {
  late final PdfControllerPinch controller;
  bool showTools = false;

  @override
  void initState() {
    super.initState();
    controller = PdfControllerPinch(
      document: PdfDocument.openAsset('assets/zaynab_book.pdf'),
    );
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: dark,
        appBar: AppBar(
          backgroundColor: dark,
          foregroundColor: gold,
          title: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('بحث عن زينب الكبرى',
                  style: TextStyle(color: gold, fontSize: 18)),
              Text('عليها السلام',
                  style: TextStyle(color: Colors.white70, fontSize: 12)),
            ],
          ),
          actions: [
            IconButton(
              onPressed: () {},
              icon: const Icon(Icons.bookmark_border),
            ),
            IconButton(
              onPressed: () => setState(() => showTools = !showTools),
              icon: const Icon(Icons.tune),
            ),
          ],
        ),
        body: Stack(
          children: [
            PdfViewPinch(controller: controller),
            if (showTools)
              Positioned(
                right: 12,
                top: 18,
                child: _ReadingTools(onClose: () {
                  setState(() => showTools = false);
                }),
              ),
          ],
        ),
        bottomNavigationBar: Container(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
          decoration: const BoxDecoration(
            color: dark,
            border: Border(top: BorderSide(color: Color(0x55E5B95C))),
          ),
          child: Row(
            children: [
              _ReaderButton(
                icon: Icons.chevron_right,
                label: 'السابق',
                onTap: () => controller.previousPage(
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOut,
                ),
              ),
              Expanded(
                child: PdfPageNumber(
                  controller: controller,
                  builder: (_, loading, page, pagesCount) => Center(
                    child: Text(
                      '$page / $pagesCount',
                      style: const TextStyle(color: gold, fontSize: 16),
                    ),
                  ),
                ),
              ),
              _ReaderButton(
                icon: Icons.chevron_left,
                label: 'التالي',
                onTap: () => controller.nextPage(
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOut,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ReaderButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _ReaderButton(
      {required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: onTap,
      icon: Icon(icon, color: gold),
      label: Text(label, style: const TextStyle(color: gold)),
      style: OutlinedButton.styleFrom(
        side: const BorderSide(color: gold),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }
}

class _ReadingTools extends StatelessWidget {
  final VoidCallback onClose;
  const _ReadingTools({required this.onClose});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: Container(
        width: 175,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xF5082E2A),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: gold),
        ),
        child: Column(
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text('إعدادات القراءة',
                      style: TextStyle(
                          color: gold, fontWeight: FontWeight.bold)),
                ),
                IconButton(
                  onPressed: onClose,
                  icon: const Icon(Icons.close, color: Colors.white70),
                ),
              ],
            ),
            _tool(Icons.text_increase, 'حجم الخط'),
            _tool(Icons.font_download_outlined, 'نوع الخط'),
            _tool(Icons.nightlight_round, 'الوضع الليلي'),
            _tool(Icons.palette_outlined, 'لون الخلفية'),
          ],
        ),
      ),
    );
  }

  Widget _tool(IconData icon, String text) => ListTile(
        dense: true,
        contentPadding: EdgeInsets.zero,
        leading: Icon(icon, color: gold),
        title: Text(text, style: const TextStyle(color: Colors.white)),
      );
}

class OrnamentPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = gold.withOpacity(.18)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;

    for (double x = 0; x < size.width; x += 44) {
      canvas.drawCircle(Offset(x, 28), 12, p);
      canvas.drawCircle(Offset(x + 22, size.height - 30), 12, p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
